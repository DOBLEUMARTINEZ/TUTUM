<div class="body-content" style="position: fixed;">
  
  <img class="background-section" src="images/img/FOTO 06.jpg">
  <span class="background-section-darkness" ></span>

  <ol class="menu-services-1">
    <li onclick="window.location.href='./identidad#us';">
      <img src="images/icons/team.png">
      <h2>¿QUIÉNES SOMOS?</h2>
    </li>
    <li onclick="window.location.href='./identidad#vision-mision';">
      <img src="images/icons/online-marketing.png">
      <h2>MISIÓN Y VISIÓN​</h2>
    </li>
    <li onclick="window.location.href='./identidad#experiencia';">
      <img src="images/icons/team.png">
      <h2>NUESTRA EXPERIENCIA​</h2>
    </li>
    <li onclick="window.location.href='./identidad#clientes';">
      <img src="images/icons/team.png">
      <h2>NUESTROS CLIENTES​</h2>
    </li>
    <li onclick="window.location.href='./identidad#socios';">
      <img src="images/icons/team.png">
      <h2>SOCIOS DE NEGOCIO</h2>
    </li>
    
  </ol>

</div>