<!-- DESCARGAR PDF -->
<div class="square-04" style="background: #0000;padding-bottom: 3%;     border-top: 15px solid #fff;">
	<ol >
		<li>
			<h2 style="padding: 10% 0%;">
				¿QUIERES SABER MÁS <br>SOBRE NOSOTROS?<br><br>
				<span>DESCARGA NUESTRO CV</span><br><br>
				<img style="width: 15%; cursor: pointer;" src="<?php echo $url ?>images/icons/pdf.png" class="arrow-down" onclick="window.open('resources/TTM-PERFIL-2022.pdf');" >
					<a href="resources/TTM-PERFIL-2022.pdf" download="TTM-PERFIL-2022"><br>Descargar Archivo</a>
			</h2>
		</li>
		<li style="text-align: center; background: #0000;">
			
		</li>
	</ol>
</div>