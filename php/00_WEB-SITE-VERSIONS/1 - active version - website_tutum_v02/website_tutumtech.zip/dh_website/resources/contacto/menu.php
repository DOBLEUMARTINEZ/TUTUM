<!-- FONDO DE SECCION -->
    <div id="square-banner-index">

	<!-- IMAGEN DE FONDO -->
	 <img class="video-slide bann-fixed" src="images/img/CAU_3.jpg">
  	<img class="video-slide" src="images/img/CAU_3.jpg" style="opacity: 0;">

  	<!-- CUADRO DE TEXTO -->
  	<div class="square-logo-big" >
	    <img src="images/logo/LOGO-WHITE.png" onclick="window.location.href='./';">
	    <h2>CONTACTO</h2>
	    
	    <i class="fas fa-chevron-down arrow-down " onclick="window.location.href='#start'"></i>
  	</div>

  	<!-- barra negra -->
      <span class="barra-negra"></span>

</div>

<!-- MENU -->
<div class="square-07">
     <ul style="justify-content: center;">
        <li id="proyectos-active" class="service-menu-color" onclick="window.location.href='contactar#start';">
            <img class="fondos fondo-proyectos" src="<?php echo $url ?>images/img/ANTONIO_SENALA.jpg">
            <img src="<?php echo $url ?>images/icons/contacto/menu/telefono.gif" class="icon-menu-black">
            <img src="<?php echo $url ?>images/icons/contacto/menu/telefono.png" class="icon-menu-white" >
            <h2>CONTACTO</h2>
        </li>
        <li id="proyectos-active" class="service-menu-color" onclick="window.location.href='bolsa-de-trabajo#start';">
            <img class="fondos fondo-proyectos" src="<?php echo $url ?>images/img/PERSONAL_9.jpg">
            <img src="<?php echo $url ?>images/icons/contacto/menu/maletin.gif" class="icon-menu-black">
            <img src="<?php echo $url;?>images/icons/contacto/menu/maletin.png" class="icon-menu-white">
            <h2>BOLSA DE TRABAJO</h2>
        </li>
        <li id="proyectos-active" class="service-menu-color" onclick="window.location.href='https://cau.tutum.com.mx/dwp/app/#/account/login?returnUrl=%2F';">
            <img src="<?php echo $url ?>images/icons/contacto/menu/apoyo-tecnico.gif" class="icon-menu-black">
            <img src="<?php echo $url;?>images/icons/contacto/menu/apoyo-tecnico.png" class="icon-menu-white" >
            <h2>CAU</h2>
        </li>
        <!--<li id="proyectos-active" class="service-menu-color" onclick="window.location.href='./';" >
            <img src="<?php echo $url ?>images/icons/contacto/menu/acceso.gif" class="icon-menu-black">
            <img src="<?php echo $url;?>images/icons/contacto/menu/acceso.png" class="icon-menu-white" >
            <h2>INTRANET</h2>
        </li>--> 
    </ul>
</div>
<a id="start"></a>


