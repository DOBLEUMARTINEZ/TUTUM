<div class="footer-W">
	<p class="copyrigt">
		Copyright © 2022 <span onclick="window.open('http://www.tutum.com.mx/')">tutum.com.mx</span>, Todos los derechos reservados.<span>Términos y Condiciones.</span>, <span>Aviso de Privacidad</span>.
	</p>
</div>

<!-- JS -->
<script src="js/jquery.min.js"></script>  
<script src="js/interactive.js"></script>

