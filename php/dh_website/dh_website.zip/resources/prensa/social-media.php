<!-- DESCARGAR PDF -->
<div class="square-04" style="background: #0000;padding-bottom: 3%;     border-top: 15px solid #fff;">
	<ol >
		<li>
			<h2 style="padding: 10% 0%;">
				¿QUIERES SABER MAS<br>SOBRE NOSOTROS?<br><br>
				<span style="color: #4DBED4" >Búscanos en redes​</span><br><br>
				<img onclick="window.open('https://www.facebook.com/Tutum-Tech-515010355546588');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/facebook.png">
				<img onclick="window.open('https://twitter.com/TutumTech');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/gorjeo.png">
				<img onclick="window.open('https://www.linkedin.com/company/tutum-tech/mycompany/verification/');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/linkedin.png">
				<img onclick="window.open('https://www.instagram.com/tutum.tech/');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/instagram.png">
				<img onclick="window.open('https://api.whatsapp.com/send?phone=525579591149&text=Hola!%20me%20pueden%20apoyar?');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/whatsapp.png">
				<img onclick="window.open('https://www.youtube.com/channel/UCjFN9qoYAGuQltMZOiuznCA/featured');" style="width: 10%;" src="<?php echo $url ?>images/icons/services/prensa/youtube.png">
			</h2>
		</li>
		<li style="text-align: center; background: #0000;">
			
		</li>
	</ol>
</div>