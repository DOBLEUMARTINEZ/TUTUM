
<!-- FONDO DE SECCION -->
    <div id="square-banner-index">

    	<!-- IMAGEN DE FONDO -->
    	<img class="video-slide bann-fixed" src="images/img/FOTO 08.jpg">
      	<img class="video-slide" src="images/img/FOTO 08.jpg" style="opacity: 0;">

      	<!-- CUADRO DE TEXTO -->
      	<div class="square-logo-big" >
      		<h2>GRACIAS POR COMUNICARTE CON TUTUM</h2>
    	    <img src="images/logo/LOGO-WHITE.png" onclick="window.location.href='./';">
      	</div>

</div>