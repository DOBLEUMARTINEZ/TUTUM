<div style="position: fixed;height: 100%; width: 100%; background: #0000;">

	<!-- BACKGPUND NEGRO TRANSPARENCIA -->
  	<span style="position: absolute; width: 100%; height: 100%; background: #000000c9;"></span>

  	<!-- IMAGEN ERROR -->
	<img style="width: 50%;z-index: 9;position: absolute;left: 25%;padding: 5%;" src="images/error.png">

	<!-- BACKGROUND VIDEO -->
  	<video class="video-slide" loading="lazy" src="https://www.tutum.com.mx/video/SOLUCIONES.mp4" autoplay="" muted="" loop=""></video>
  	
</div>