
<style type="text/css">
	#modulo-not-found-content  h1 {
	    width: 100%;
	    font-weight: bold;
	    color: #CC6633;
	    letter-spacing: 0.5px;
	    position: relative;
	    text-align: center;
	    margin: 2% 0 5% 0;
	}
</style>
<!-- ERROR 404 -->
<div id="modulo-not-found-content">
	<center>
		<img onclick="window.location.href='./';" src="images/img/error-404-2.jpg" style="width: 50%;"><br>
		<h1>Página en mantenimiento</h1>
	</center>
</div>






