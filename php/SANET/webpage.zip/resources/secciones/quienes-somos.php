<!-- BANNER INICIO -->
<div id="quienes-somos-content">

 <div class="bloque-1">
   <ul>

     <li>

      <div>

        <h1>
          Quiénes somos
          <img src="images/img/quienes-somos-2.jpg">
        </h1>

        <p>
          Somos una empresa, dinámica, innovadora y cienporciento mexicana; dedicada a brindar servicios de consultoría tecnológica y soluciones integrales de TI. Estamos comprometidos con el desarrollo económico y social del país, así como con nuestros clientes, socios y colaboradores.
        </p>

      </div>

     </li>

     <li><img src="images/img/quienes-somos.jpg"></li>
   </ul>
 </div>

</div>

<div id="nuestra-experiencia-content">

  <div class="bloque-1">

    <div>
      <img src="images/img/nuestra-experiencia-1.jpg">
    </div>

    <ul>
      <li>
        <h1>Nuestra experiencia</h1>
      </li>
      <li>
        <p>
          Tenemos experiencia en los sectores de salud, gestión hospitalaria, seguridad nacional, finanzas, infraestructura e industrial. Para brindar un alcance y soporte a nivel nacional, contamos con una cobertura de centros de atención a usuarios y distribución en seis regiones estratégicamente ubicadas en la república mexicana.
        </p>
      </li>
      <img src="images/img/nuestra-experiencia-2.jpg">
    </ul>

  </div>

</div>







