<!-- BANNER INICIO -->
<div id="nuestra-experiencia-content">

  <div class="bloque-1">

    <div>
      <img src="images/img/nuestra-experiencia-1.jpg">
    </div>

    <ul>
      <li>
        <h1>Nuestra Experiencia</h1>
      </li>
      <li>
        <p>
          Tenemos experiencia en los sectores de Salud, Gestión Hospitalaria, Seguridad Nacional, Finanzas, Infraestructura e Industrial. Para brindar un alcance y soporte a nivel nacional, contamos con una cobertura de centros de atención a usuarios y distribución en seis regiones estratégicamente ubicadas en la república mexicana.
        </p>
      </li>
      <img src="images/img/nuestra-experiencia-2.jpg">
    </ul>

  </div>

</div>







