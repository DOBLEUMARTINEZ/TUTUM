<div id="modulo-gracias-content">

	<div class="thank-you">
		<ol>
			<li>
				<img src="images/img/gracias.jpg"  class="desktop" style="width: 100%;">
				<img src="images/img/gracias-tablet.jpg"  class="tablet" style="width: 100%;">
				<img src="images/img/gracias-mobil.jpg"  class="mobil" style="width: 100%;">
			</li>
			<li>
				<h1>Gracias por contactarnos</h1>
				<p>
					Nos emociona poder ayudarte a solucionar tus problemas de gestión de información clínica hospitalaria.<br><br> En breve nos pondremos en contacto.
				</p>
				<ul>
					<li> <button onclick="window.location.href='<?php echo $url;?>';">Regresar a pagina web</button> </li>
					<li>
						<i class="fab fa-facebook-f"></i>
						<i class="fab fa-whatsapp"></i>
						<i class="fab fa-linkedin-in"></i>
					</li>
				</ul>
			</li>
		</ol>
	</div>

</div>